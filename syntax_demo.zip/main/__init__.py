# -*- coding: utf-8 -*-
"""
Jython (Python 2.x) 与 Python 3.x 语法区别验证模组
本脚本演示 Jython 中的特有语法和注意事项
"""

# 获取logger（由Java传入）
try:
	LOGGER = LOGGER
except NameError:
	# 如果没有传入logger，使用默认的print
	class DefaultLogger:
		def _safe_print(self, prefix, msg):
			"""安全地打印消息，处理编码问题"""
			try:
				print(prefix + " " + str(msg))
			except UnicodeEncodeError:
				# 如果编码失败，使用ASCII安全输出
				safe_msg = str(msg).encode('ascii', errors='replace').decode('ascii')
				print(prefix + " " + safe_msg)

		def info(self, msg): self._safe_print("[INFO]", msg)
		def warn(self, msg): self._safe_print("[WARN]", msg)
		def warning(self, msg): self._safe_print("[WARN]", msg)
		def error(self, msg): self._safe_print("[ERROR]", msg)
		def debug(self, msg): self._safe_print("[DEBUG]", msg)
	LOGGER = DefaultLogger()


def main():
	"""
	主函数：演示 Jython 与 Python 3 的语法区别
	"""

	# ============================================
	# 1. Print 语句 vs Print 函数
	# ============================================
	LOGGER.info("=" * 50)
	LOGGER.info("1. Print 语法测试")
	LOGGER.info("=" * 50)

	# Jython (Python 2) 支持两种写法
	LOGGER.info("这是 Python 2 的 print 语句语法（无括号）")
	LOGGER.info("这是 Python 3 的 print 函数语法（有括号）")

	# 带逗号的 print（自动添加空格）
	LOGGER.info("打印多个值: " + str(123) + " abc " + str(True))

	# 输出多个值
	LOGGER.info("值1: 123, 值2: abc, 值3: True")


	# ============================================
	# 2. 字符串类型：str vs unicode
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("2. 字符串类型测试")
	LOGGER.info("=" * 50)

	# 普通字符串（字节串）
	ascii_str = "Hello World"
	LOGGER.info("ASCII 字符串: " + ascii_str)
	LOGGER.info("ASCII 类型: " + str(type(ascii_str)))

	# Unicode 字符串
	unicode_str = u"你好世界"
	LOGGER.info("Unicode 字符串: " + unicode_str)
	LOGGER.info("Unicode 类型: " + str(type(unicode_str)))

	# 中文（如果没有 u 前缀，是字节串）
	chinese_bytes = "中文字符"
	LOGGER.info("中文字节串类型: " + str(type(chinese_bytes)))

	# 混合使用
	mixed = ascii_str + unicode_str
	LOGGER.info("拼接结果: " + mixed)
	LOGGER.info("拼接类型: " + str(type(mixed)))


	# ============================================
	# 3. 整数除法
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("3. 整数除法测试")
	LOGGER.info("=" * 50)

	# Python 2 中，整数除整数结果还是整数（向下取整）
	LOGGER.info("5 / 2 = " + str(5 / 2))
	LOGGER.info("5 / 2.0 = " + str(5 / 2.0))
	LOGGER.info("5.0 / 2 = " + str(5.0 / 2))

	LOGGER.info("")
	LOGGER.info("使用浮点数除法:")
	LOGGER.info("5 / float(2) = " + str(5 / float(2)))


	# ============================================
	# 4. 异常语法
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("4. 异常语法测试")
	LOGGER.info("=" * 50)

	# Python 2 语法：使用逗号
	try:
		result = 1 / 0
	except ZeroDivisionError, e:
		LOGGER.info("捕获异常（逗号语法）: " + str(e))
	except Exception, e:
		LOGGER.info("通用异常: " + str(e))


	# ============================================
	# 5. range vs xrange
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("5. Range 测试")
	LOGGER.info("=" * 50)

	# Python 2 的 range 返回列表
	r = range(5)
	LOGGER.info("range(5) 结果: " + str(r))
	LOGGER.info("range(5) 类型: " + str(type(r)))

	# Python 2 的 xrange 返回迭代器（更省内存）
	xr = xrange(5)
	LOGGER.info("xrange(5) 结果: " + str(xr))
	LOGGER.info("xrange(5) 类型: " + str(type(xr)))

	# 在循环中使用
	LOGGER.info("使用 range 遍历:")
	for i in range(3):
		LOGGER.info("  - " + str(i))


	# ============================================
	# 6. 字典方法
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("6. 字典方法测试")
	LOGGER.info("=" * 50)

	d = {"a": 1, "b": 2, "c": 3}

	# Python 2 的 iter* 方法
	LOGGER.info("字典: " + str(d))
	LOGGER.info(".keys() 返回列表: " + str(d.keys()))
	LOGGER.info(".values() 返回列表: " + str(d.values()))
	LOGGER.info(".items() 返回列表: " + str(d.items()))
	LOGGER.info("类型: " + str(type(d.keys())))

	# 迭代器版本
	LOGGER.info("")
	LOGGER.info("使用 iter* 方法:")
	LOGGER.info(".iterkeys(): " + str(list(d.iterkeys())))
	LOGGER.info(".itervalues(): " + str(list(d.itervalues())))
	LOGGER.info(".iteritems(): " + str(list(d.iteritems())))


	# ============================================
	# 7. 比较运算符
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("7. 比较运算符测试")
	LOGGER.info("=" * 50)

	# Python 2 支持链式比较和多种比较方式
	LOGGER.info("1 < 2 < 3: " + str(1 < 2 < 3))
	LOGGER.info("3 > 2 > 1: " + str(3 > 2 > 1))

	# None 和数字可以比较（Python 2 特性，Python 3 会报错）
	LOGGER.info("None < 10: " + str(None < 10))


	# ============================================
	# 8. 输入函数
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("8. 输入函数测试")
	LOGGER.info("=" * 50)

	LOGGER.info("input() 会执行输入的代码（危险）")
	LOGGER.info("raw_input() 返回原始字符串")
	LOGGER.info("（此处不实际测试，因为会阻塞）")


	# ============================================
	# 9. Long 类型
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("9. Long 类型测试")
	LOGGER.info("=" * 50)

	# Python 2 有 int 和 long 两种整数类型
	small_num = 100
	LOGGER.info("小整数: " + str(small_num) + " 类型: " + str(type(small_num)))

	big_num = 10000000000L
	LOGGER.info("大整数（带L）: " + str(big_num) + " 类型: " + str(type(big_num)))

	auto_long = 10000000000
	LOGGER.info("自动提升: " + str(auto_long) + " 类型: " + str(type(auto_long)))


	# ============================================
	# 10. 列表推导式作用域
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("10. 列表推导式测试")
	LOGGER.info("=" * 50)

	# Python 2 中，列表推导式的变量会泄漏到外部作用域
	result = [x * 2 for x in range(5)]
	LOGGER.info("列表推导结果: " + str(result))
	LOGGER.info("变量 x 的值: " + str(x))
	LOGGER.info("变量 x 存在: " + str('x' in dir()))


	# ============================================
	# 11. 字节和字符串
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("11. 字节和字符串测试")
	LOGGER.info("=" * 50)

	# 在 Python 2 中，str 就是字节
	byte_str = "ABC"
	LOGGER.info("字符串: " + byte_str)
	LOGGER.info("长度: " + str(len(byte_str)))
	LOGGER.info("str 和 bytes 的关系: " + str(type(byte_str)))


	# ============================================
	# 12. Python 3 特性测试
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("12. Python 3 特性测试")
	LOGGER.info("=" * 50)

	LOGGER.info("以下特性在 Jython (Python 2) 中不支持:")
	LOGGER.info("- 函数参数类型注解 (def func(x: int) -> int: ...)")
	LOGGER.info("- 关键字参数 only (def func(*, arg): ...)")
	LOGGER.info("- super() 无参数调用")
	LOGGER.info("- 非局部变量 (nonlocal 关键字)")
	LOGGER.info("- yield from 语法")
	LOGGER.info("- 字典的键()方法")

	LOGGER.info("")
	LOGGER.info("可用的 __future__ 导入:")
	LOGGER.info("- division (改变除法行为)")
	LOGGER.info("- print_function (使 print 成为函数)")
	LOGGER.info("- unicode_literals (使字符串默认为 unicode)")
	LOGGER.info("- with_statement (with 语句)")


	# ============================================
	# 总结
	# ============================================
	LOGGER.info("")
	LOGGER.info("=" * 50)
	LOGGER.info("总结")
	LOGGER.info("=" * 50)
	LOGGER.info("Jython 使用 Python 2.x 语法")
	LOGGER.info("主要注意事项：")
	LOGGER.info("1. print 可以用作语句（无括号）")
	LOGGER.info("2. 字符串区分 str（字节）和 unicode")
	LOGGER.info("3. 整数除法向下取整")
	LOGGER.info("4. 异常使用逗号: except Exception, e:")
	LOGGER.info("5. range 返回列表，xrange 返回迭代器")
	LOGGER.info("6. 有 int 和 long 两种整数类型")
	LOGGER.info("7. 总是为中文添加 u 前缀或声明文件编码")
	LOGGER.info("=" * 50)


if __name__ == "__main__":
	main()
